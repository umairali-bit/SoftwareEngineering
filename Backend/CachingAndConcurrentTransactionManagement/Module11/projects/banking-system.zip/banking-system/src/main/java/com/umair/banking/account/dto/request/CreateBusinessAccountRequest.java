package com.umair.banking.account.dto.request;


import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record CreateBusinessAccountRequest(

        @NotNull
        Long customerId,

        @NotNull
        String registrationNumber,

        @NotNull
        BigDecimal creditLimit
) {




}
