package com.example.ThridPartyAPICallsWithRestClient.ThridPartyAPICallsWithRestClient.exceptions;

public class ResourceNotFoundException extends RuntimeException{

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
