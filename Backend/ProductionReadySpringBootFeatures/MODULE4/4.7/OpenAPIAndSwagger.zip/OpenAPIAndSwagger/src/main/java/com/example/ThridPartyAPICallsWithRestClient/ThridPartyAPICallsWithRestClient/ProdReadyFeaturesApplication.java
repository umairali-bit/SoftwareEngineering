package com.example.ThridPartyAPICallsWithRestClient.ThridPartyAPICallsWithRestClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdReadyFeaturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdReadyFeaturesApplication.class, args);
	}

}
